function getInputValue() {
var inputValue = document.getElementById('exampleInputEmail1').value;
console.log(inputValue);
document.getElementById('exampleInputPassword1').innerHTML=inputValue;
}

